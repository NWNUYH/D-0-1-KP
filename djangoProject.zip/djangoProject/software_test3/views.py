from django.shortcuts import render
from software_test3.models import cal
from django.http import HttpResponse
# Create your views here.

def Index (request):
    return render(request, 'index.html')

def CalPage(request):
    return render(request, 'cal.html')

def Cal(request):
    if request.method == 'POST':
        value_a = request.POST['valueA']
        value_b = request.POST['valueB']
        result = int(value_a) + int(value_b)
        cal.objects.create(value_a=value_a, value_b=value_b, result=result)
    else:
        return HttpResponse('please vist us with post')
    return render(request, 'result.html', context={'data':result})

def CalList(request):
    data = cal.objects.all()
    #for data in data:
        #print(data.value_a,data.value_b,data.result)
    return render(request, 'list.html', context={'data':data})

def DelData(request):
    cal.objects.all().delete()
    return HttpResponse('data Deleted')


